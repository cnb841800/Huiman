# 辉漫 Android 动漫播放器

版本：0.4.0（源码包，尚未完成 Android SDK 构建验证）

## 本版新增
- 多线路本地管理：可为线路命名、保存、选择和删除。
- 自定义 HTTP/HTTPS 播放地址。
- HLS（m3u8）与 DASH（mpd）基础播放支持。
- 画质上限：自动、4K、2K、1080P；实际清晰度取决于源站轨道和设备解码能力。
- 最近播放记录。
- AniList GraphQL 动漫元数据搜索。

## 重要说明
- AniList 是动漫元数据 API，不提供视频流或播放授权。
- 本应用不会自动提取受限媒体流、抓取 Cookie 或绕过 DRM、会员及地区限制。
- 仅添加你有权访问和播放的地址。
- 4K 档位只是分辨率上限，不保证片源实际提供 4K。

## 构建
使用 Android Studio 打开本目录，等待 Gradle 同步后选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。

需要 Android SDK、JDK 及 Gradle 依赖访问。当前执行环境未确认具备完整 Android 构建链，因此本源码包尚未声称编译通过。


## 云端构建 APK（无需本机安装 Android SDK）
1. 将 `huiman_build` 目录中的内容上传到 GitHub 仓库根目录（包含隐藏目录 `.github/workflows`）。
2. 打开仓库的 Actions 页面。
3. 运行 `Build HuiMan APK` 工作流，或推送到 `main` / `master` 分支自动构建。
4. 工作流成功后，在运行记录的 Artifacts 中下载 `huiman-debug-apk`，其中包含 `app-debug.apk`。
5. 这是 debug 测试包；正式发布前应配置自己的 release 签名。

当前执行环境没有 Gradle 和 Android SDK，故无法在此直接生成或验证 APK。工作流会在 GitHub 托管的 Android 构建环境中完成编译。
