package com.huiman.app

import android.graphics.Color
import android.net.Uri
import android.content.Intent
import android.app.AlertDialog
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import org.json.JSONObject
import org.json.JSONArray
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private lateinit var qualitySpinner: Spinner
    private lateinit var historySpinner: Spinner
    private lateinit var sourceSpinner: Spinner
    private var sourceItems: List<Pair<String, String>> = emptyList()
    private var updatingSources = false
    private val qualityLabels = listOf("自动画质", "4K 优先（最高 2160p）", "2K 优先（最高 1440p）", "1080P 优先")
    private var selectedQuality = 0
    private val apiExecutor = Executors.newSingleThreadExecutor()
    private lateinit var animeSearchInput: EditText
    private lateinit var animeResults: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 16, 24)
        window.navigationBarColor = Color.rgb(16, 16, 24)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 18)
            setBackgroundColor(Color.rgb(16, 16, 24))
        }
        val scroll = ScrollView(this).apply { addView(content) }

        content.addView(TextView(this).apply {
            text = "辉漫  ·  动漫播放器"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(0, 4, 0, 14)
        })

        playerView = PlayerView(this).apply {
            useController = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230))
        }
        content.addView(playerView)

        content.addView(sectionLabel("播放画质"))
        qualitySpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, qualityLabels)
            setSelection(selectedQuality)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    selectedQuality = position
                    applyQualityLimit()
                }
            }
        }
        content.addView(qualitySpinner)

        content.addView(sectionLabel("播放地址"))
        urlInput = EditText(this).apply {
            hint = "https://example.com/video.m3u8"
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF777788.toInt())
            singleLine = true
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            setPadding(12, 10, 12, 10)
            setBackgroundColor(0xFF252536.toInt())
        }
        content.addView(urlInput)
        content.addView(sectionLabel("我的片源线路"))
        sourceSpinner = Spinner(this)
        content.addView(sourceSpinner)
        sourceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (!updatingSources && position in sourceItems.indices) urlInput.setText(sourceItems[position].second)
            }
        }
        val sourceActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sourceActions.addView(Button(this).apply {
            text = "保存当前线路"
            setOnClickListener { promptSaveSource() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        sourceActions.addView(Button(this).apply {
            text = "删除所选"
            setOnClickListener { deleteSelectedSource() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        content.addView(sourceActions)
        refreshSources()
        content.addView(Button(this).apply {
            text = "播放 / 切换线路"
            setOnClickListener { playUrl(urlInput.text.toString().trim()) }
        })

        content.addView(sectionLabel("最近播放"))
        historySpinner = Spinner(this)
        content.addView(historySpinner)
        refreshHistory()
        historySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val history = getHistory()
                if (position in history.indices) urlInput.setText(history[position])
            }
        }

        content.addView(sectionLabel("正版动漫资料库（AniList）"))
        animeSearchInput = EditText(this).apply {
            hint = "搜索动漫名称"
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF777788.toInt())
            singleLine = true
            setPadding(12, 10, 12, 10)
            setBackgroundColor(0xFF252536.toInt())
        }
        content.addView(animeSearchInput)
        content.addView(Button(this).apply {
            text = "搜索动漫资料"
            setOnClickListener { searchAnime(animeSearchInput.text.toString().trim()) }
        })
        animeResults = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(animeResults)
        animeResults.addView(resultText("资料来自 AniList 公共 API；点击条目打开官方资料页。此 API 不提供视频流或播放授权。"))

        status = TextView(this).apply {
            text = "就绪。选择画质上限后播放你有权使用的片源。"
            setTextColor(0xFFB8B8C8.toInt())
            textSize = 12f
            setPadding(0, 12, 0, 0)
        }
        content.addView(status)
        content.addView(TextView(this).apply {
            text = "说明：画质档位仅限制最高分辨率，实际画质取决于片源是否提供对应轨道。4K 流畅度还取决于网络码率、服务器和设备解码能力。本应用不内置未经授权的动漫片源。"
            setTextColor(0xFF888899.toInt())
            textSize = 12f
            setPadding(0, 18, 0, 0)
        })
        setContentView(scroll)
    }

    /** AniList provides catalog metadata only, not streaming rights or video URLs. */
    private fun searchAnime(keyword: String) {
        if (keyword.isBlank()) {
            status.text = "请输入动漫名称。"
            return
        }
        status.text = "正在搜索动漫资料…"
        animeResults.removeAllViews()
        animeResults.addView(resultText("正在连接 AniList…"))
        apiExecutor.execute {
            try {
                val query = """
                    query (${'$'}search: String) {
                      Page(page: 1, perPage: 20) {
                        media(search: ${'$'}search, type: ANIME, sort: SEARCH_MATCH) {
                          id
                          title { romaji english native }
                          description(asHtml: false)
                          episodes
                          seasonYear
                          format
                          genres
                          siteUrl
                        }
                      }
                    }
                """.trimIndent()
                val payload = JSONObject().put("query", query)
                    .put("variables", JSONObject().put("search", keyword))
                val connection = URL("https://graphql.anilist.co").openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.connectTimeout = 12000
                connection.readTimeout = 15000
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                connection.setRequestProperty("Accept", "application/json")
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                connection.disconnect()
                if (code !in 200..299) throw IllegalStateException("AniList HTTP $code")
                val root = JSONObject(body)
                if (root.has("errors")) throw IllegalStateException("AniList API 返回错误")
                val media = root.getJSONObject("data").getJSONObject("Page").getJSONArray("media")
                runOnUiThread {
                    animeResults.removeAllViews()
                    for (i in 0 until media.length()) {
                        val item = media.getJSONObject(i)
                        val titles = item.getJSONObject("title")
                        val name = titles.optString("english").takeIf { it.isNotBlank() }
                            ?: titles.optString("romaji").takeIf { it.isNotBlank() }
                            ?: titles.optString("native")
                        val detail = buildString {
                            append(item.optString("format", "未知类型"))
                            item.optInt("seasonYear").takeIf { it > 0 }?.let { append(" · ").append(it) }
                            item.optInt("episodes").takeIf { it > 0 }?.let { append(" · ").append(it).append(" 集") }
                            val genres = item.optJSONArray("genres")
                            if (genres != null && genres.length() > 0) {
                                append("\\n").append((0 until minOf(genres.length(), 5)).joinToString(" / ") { genres.optString(it) })
                            }
                        }
                        @Suppress("DEPRECATION")
                        val description = android.text.Html.fromHtml(
                            item.optString("description")
                        ).toString().replace(Regex("\\s+"), " ").take(180)
                        val card = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL
                            setPadding(dp(10), dp(9), dp(10), dp(9))
                            setBackgroundColor(0xFF252536.toInt())
                        }
                        card.addView(TextView(this).apply {
                            text = name; textSize = 16f; setTextColor(Color.WHITE)
                        })
                        card.addView(TextView(this).apply {
                            text = detail; textSize = 11f; setTextColor(0xFFBCA9E8.toInt())
                        })
                        if (description.isNotBlank()) card.addView(TextView(this).apply {
                            text = description; textSize = 12f; setTextColor(0xFFB8B8C8.toInt())
                        })
                        card.setOnClickListener {
                            val link = item.optString("siteUrl")
                            if (link.startsWith("https://anilist.co/")) {
                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                            }
                        }
                        val params = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { bottomMargin = dp(8) }
                        animeResults.addView(card, params)
                    }
                    if (media.length() == 0) animeResults.addView(resultText("没有找到匹配的动漫。"))
                    status.text = "AniList 搜索完成：${media.length()} 条资料。"
                }
            } catch (error: Exception) {
                runOnUiThread {
                    animeResults.removeAllViews()
                    animeResults.addView(resultText("搜索失败：${error.message ?: "网络或 API 暂不可用"}"))
                    status.text = "动漫资料搜索失败，请检查网络后重试。"
                }
            }
        }
    }

    private fun promptSaveSource() {
        val url = urlInput.text.toString().trim()
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            status.text = "请先输入有效的 http(s) 播放地址。"
            return
        }
        val nameInput = EditText(this).apply { hint = "例如：第 1 线路 / 备用线路" }
        AlertDialog.Builder(this)
            .setTitle("保存片源线路")
            .setMessage("仅保存你有权访问的播放地址。")
            .setView(nameInput)
            .setPositiveButton("保存") { _, _ ->
                val name = nameInput.text.toString().trim().ifBlank { "线路 ${sourceItems.size + 1}" }
                val updated = (listOf(name to url) + sourceItems.filterNot { it.second == url }).take(100)
                saveSources(updated)
                refreshSources()
                status.text = "已保存线路：$name"
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun deleteSelectedSource() {
        val position = if (::sourceSpinner.isInitialized) sourceSpinner.selectedItemPosition else -1
        if (position !in sourceItems.indices) {
            status.text = "请先选择一条已保存线路。"
            return
        }
        val removed = sourceItems[position]
        val updated = sourceItems.filterIndexed { index, _ -> index != position }
        saveSources(updated)
        refreshSources()
        status.text = "已删除线路：${removed.first}"
    }

    private fun getSources(): List<Pair<String, String>> {
        val raw = getSharedPreferences("huiman", MODE_PRIVATE).getString("sources", "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val name = item.optString("name").trim()
                val url = item.optString("url").trim()
                if (name.isNotBlank() && (url.startsWith("https://") || url.startsWith("http://"))) name to url else null
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun saveSources(items: List<Pair<String, String>>) {
        val array = JSONArray()
        items.forEach { (name, url) -> array.put(JSONObject().put("name", name).put("url", url)) }
        getSharedPreferences("huiman", MODE_PRIVATE).edit().putString("sources", array.toString()).apply()
    }

    private fun refreshSources() {
        if (!::sourceSpinner.isInitialized) return
        sourceItems = getSources()
        val labels = if (sourceItems.isEmpty()) listOf("暂无保存线路") else sourceItems.map { "${it.first} · ${it.second.take(42)}" }
        updatingSources = true
        sourceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        updatingSources = false
    }

    private fun resultText(value: String) = TextView(this).apply {
        text = value; textSize = 12f; setTextColor(0xFFB8B8C8.toInt())
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun sectionLabel(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        setTextColor(0xFFE2D7FF.toInt())
        setPadding(0, 14, 0, 6)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun playUrl(url: String) {
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            status.text = "请输入有效的 http(s) 视频地址。"
            return
        }
        releasePlayer()
        val exo = ExoPlayer.Builder(this).build()
        player = exo
        playerView.player = exo
        applyQualityLimit()
        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                status.text = when (playbackState) {
                    Player.STATE_BUFFERING -> "正在缓冲…"
                    Player.STATE_READY -> "已就绪 / 正在播放 · ${qualityLabels[selectedQuality]}"
                    Player.STATE_ENDED -> "播放结束"
                    else -> "播放器已初始化"
                }
            }
            override fun onPlayerError(error: PlaybackException) {
                status.text = "播放失败：请检查链接、网络、授权状态或视频编码格式。"
            }
        })
        val itemBuilder = MediaItem.Builder().setUri(Uri.parse(url))
        when {
            url.contains(".m3u8", true) -> itemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
            url.contains(".mpd", true) -> itemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
        }
        exo.setMediaItem(itemBuilder.build())
        exo.prepare()
        exo.playWhenReady = true
        saveHistory(url)
        refreshHistory()
        status.text = "正在连接片源…"
    }

    /** Sets a resolution ceiling; ExoPlayer still adapts to available tracks and bandwidth. */
    private fun applyQualityLimit() {
        val dimensions = when (selectedQuality) {
            1 -> 3840 to 2160
            2 -> 2560 to 1440
            3 -> 1920 to 1080
            else -> null
        }
        val current = player ?: return
        val builder = current.trackSelectionParameters.buildUpon()
        if (dimensions == null) {
            builder.clearVideoSizeConstraints()
        } else {
            builder.setMaxVideoSize(dimensions.first, dimensions.second)
        }
        current.trackSelectionParameters = builder.build()
    }

    private fun getHistory(): List<String> = getSharedPreferences("huiman", MODE_PRIVATE)
        .getString("history", "").orEmpty().split('\n').filter { it.isNotBlank() }

    private fun saveHistory(url: String) {
        val updated = (listOf(url) + getHistory().filterNot { it == url }).take(20)
        getSharedPreferences("huiman", MODE_PRIVATE).edit().putString("history", updated.joinToString("\n")).apply()
    }

    private fun refreshHistory() {
        if (!::historySpinner.isInitialized) return
        val history = getHistory()
        val labels = if (history.isEmpty()) listOf("暂无播放记录") else history.map { it.take(58) }
        historySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
    }

    private fun releasePlayer() {
        if (::playerView.isInitialized) playerView.player = null
        player?.release()
        player = null
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        apiExecutor.shutdownNow()
        releasePlayer()
        super.onDestroy()
    }
}
